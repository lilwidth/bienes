import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Bed, Bath, Square, Car, Wrench as Tool, CheckCircle } from 'lucide-react';

const PropertyCard = ({ item, index, category }) => {
  const renderIcon = () => {
    switch (category) {
      case 'Inmuebles':
        return <Bed className="h-4 w-4 mr-1 text-primary" />;
      case 'Vehículos':
        return <Car className="h-4 w-4 mr-1 text-primary" />;
      case 'Otros Bienes':
        return <Tool className="h-4 w-4 mr-1 text-primary" />;
      default:
        return <CheckCircle className="h-4 w-4 mr-1 text-primary" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5, scale: 1.01 }}
      className="group h-full flex flex-col"
    >
      <Card className="overflow-hidden border-border transition-all duration-300 hover:shadow-xl bg-card flex-grow flex flex-col">
        <div className="relative overflow-hidden">
          <img 
            className="w-full h-56 object-cover transition-transform duration-500 group-hover:scale-110"
            alt={`${item.title} - ${item.type}`}
             src="https://images.unsplash.com/photo-1598020856638-cbc3b47bbada" />
          <div className="absolute top-3 left-3">
            <span className="bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold shadow-md">
              {item.type}
            </span>
          </div>
          {item.price && (
            <div className="absolute bottom-3 right-3">
              <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-base font-bold shadow-md">
                ${item.price.toLocaleString()}
              </span>
            </div>
          )}
        </div>
        
        <CardContent className="p-5 flex-grow">
          <h3 className="text-lg font-semibold mb-2 text-foreground">{item.title}</h3>
          {item.location && (
            <div className="flex items-center text-muted-foreground mb-3">
              <MapPin className="h-4 w-4 mr-1.5" />
              <span className="text-sm">{item.location}</span>
            </div>
          )}
          
          {category === 'Inmuebles' && item.bedrooms && item.bathrooms && item.area && (
            <div className="flex items-center space-x-3 text-sm text-muted-foreground mb-3">
              <div className="flex items-center">
                <Bed className="h-4 w-4 mr-1" />
                <span>{item.bedrooms}</span>
              </div>
              <div className="flex items-center">
                <Bath className="h-4 w-4 mr-1" />
                <span>{item.bathrooms}</span>
              </div>
              <div className="flex items-center">
                <Square className="h-4 w-4 mr-1" />
                <span>{item.area}m²</span>
              </div>
            </div>
          )}

          {category === 'Vehículos' && item.year && item.mileage && (
             <div className="flex items-center space-x-3 text-sm text-muted-foreground mb-3">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1" />
                <span>Año: {item.year}</span>
              </div>
              <div className="flex items-center">
                <Car className="h-4 w-4 mr-1" />
                <span>{item.mileage} Km</span>
              </div>
            </div>
          )}
          
          <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
        </CardContent>
        <CardFooter className="p-5 border-t border-border">
          <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium transition-all duration-300">
            Ver Detalles
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default PropertyCard;