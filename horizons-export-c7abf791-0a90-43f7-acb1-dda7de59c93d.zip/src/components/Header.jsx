import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Menu, X, Building, Car, Info, Briefcase, Mail, PlusCircle } from 'lucide-react';
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navItems = [
    { to: "/", icon: <Building className="h-5 w-5 mr-2" />, text: "Inicio" },
    { to: "/catalogo", icon: <Car className="h-5 w-5 mr-2" />, text: "Catálogo" },
    { to: "/servicios", icon: <Briefcase className="h-5 w-5 mr-2" />, text: "Servicios" },
    { to: "/sobre-nosotros", icon: <Info className="h-5 w-5 mr-2" />, text: "Sobre Mí" },
    { to: "/contacto", icon: <Mail className="h-5 w-5 mr-2" />, text: "Contáctanos" },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md shadow-md border-b border-border"
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Building className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-foreground">
              Alvarez<span className="text-accent">Bienes</span>
            </span>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center text-foreground hover:text-accent transition-colors font-medium ${isActive ? "text-accent" : ""}`
                }
              >
                {item.icon && React.cloneElement(item.icon, { className: `h-4 w-4 mr-1 ${item.to === "/" ? "hidden" : ""}` })}
                {item.text}
              </NavLink>
            ))}
          </nav>
          
          <div className="hidden md:flex items-center space-x-3">
            <Button asChild variant="outline" className="border-accent text-accent hover:bg-accent hover:text-primary-foreground">
              <Link to="/publica-tu-bien">
                <PlusCircle className="h-4 w-4 mr-2" />
                Publica tu Bien
              </Link>
            </Button>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-foreground hover:bg-secondary"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
        
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mt-3 pb-3 border-t border-border"
          >
            <nav className="flex flex-col space-y-3 mt-3">
              {navItems.map((item) => (
                 <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={toggleMenu}
                  className={({ isActive }) =>
                    `flex items-center py-2 px-3 rounded-md text-foreground hover:bg-secondary hover:text-accent transition-colors font-medium ${isActive ? "bg-secondary text-accent" : ""}`
                  }
                >
                  {item.icon} {item.text}
                </NavLink>
              ))}
              <Button asChild variant="outline" className="w-full mt-2 border-accent text-accent hover:bg-accent hover:text-primary-foreground">
                <Link to="/publica-tu-bien" onClick={toggleMenu}>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Publica tu Bien
                </Link>
              </Button>
            </nav>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
};

export default Header;