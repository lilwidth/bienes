import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Edit3 } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <section id="inicio" className="relative min-h-[calc(100vh-80px)] mt-[80px] flex items-center justify-center overflow-hidden gradient-bg-hero">
      <div className="absolute inset-0 opacity-10">
         <img 
          className="w-full h-full object-cover" 
          alt="Panorama de Tarija con casas modernas y vehículos elegantes"
           src="https://images.unsplash.com/photo-1603489421476-477fe1c71582" />
      </div>
      
      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="floating-animation"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="block">Tu conexión confiable para</span>
            <span className="block text-gradient-accent">comprar, vender o alquilar</span>
            <span className="block">bienes en Tarija.</span>
          </h1>
          <p className="text-xl md:text-2xl mb-10 text-gray-300 max-w-2xl mx-auto">
            Conectamos compradores y vendedores de manera segura y profesional.
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-primary-foreground font-semibold px-8 py-4 text-lg pulse-glow-accent">
            <Link to="/catalogo">
              Ver Propiedades Disponibles
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
          
          <Button asChild size="lg" variant="outline" className="border-gray-400 text-gray-200 hover:bg-white/10 hover:text-white hover:border-white px-8 py-4 text-lg">
            <Link to="/publica-tu-bien">
              <Edit3 className="mr-2 h-5 w-5" />
              Publica tu Bien
            </Link>
          </Button>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto"
        >
          <div className="glass-effect rounded-xl p-5 text-center">
            <h3 className="text-2xl font-bold text-accent">Inmuebles</h3>
            <p className="text-gray-300 text-sm">Casas, Deptos, Terrenos</p>
          </div>
          <div className="glass-effect rounded-xl p-5 text-center">
            <h3 className="text-2xl font-bold text-accent">Vehículos</h3>
            <p className="text-gray-300 text-sm">Autos, Motos, Camionetas</p>
          </div>
          <div className="glass-effect rounded-xl p-5 text-center">
            <h3 className="text-2xl font-bold text-accent">Asesoría</h3>
            <p className="text-gray-300 text-sm">Compra, Venta, Alquiler</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;