import React from 'react';
import { Building, Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const socialLinks = [
    { icon: <Facebook className="h-5 w-5" />, href: "https://facebook.com", label: "Facebook" },
    { icon: <Twitter className="h-5 w-5" />, href: "https://twitter.com", label: "Twitter" },
    { icon: <Instagram className="h-5 w-5" />, href: "https://instagram.com", label: "Instagram" },
    { icon: <Linkedin className="h-5 w-5" />, href: "https://linkedin.com", label: "LinkedIn" },
  ];

  const quickLinks = [
    { to: "/", text: "Inicio" },
    { to: "/catalogo", text: "Catálogo" },
    { to: "/servicios", text: "Servicios" },
    { to: "/sobre-nosotros", text: "Sobre Mí" },
    { to: "/publica-tu-bien", text: "Publica tu Bien" },
    { to: "/contacto", text: "Contacto" },
  ];

  return (
    <footer className="bg-slate-800 text-slate-300 border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Building className="h-8 w-8 text-accent" />
              <span className="text-2xl font-bold text-white">
                Alvarez<span className="text-accent">Bienes</span>
              </span>
            </Link>
            <p className="text-sm">
              Tu conexión confiable para comprar, vender o alquilar bienes en Tarija. Comprometidos con la honestidad y los resultados.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map(link => (
                <a key={link.label} href={link.href} target="_blank" rel="noopener noreferrer" aria-label={link.label} className="text-slate-400 hover:text-accent transition-colors">
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <p className="text-lg font-semibold text-white mb-4">Enlaces Rápidos</p>
            <ul className="space-y-2">
              {quickLinks.map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="hover:text-accent transition-colors text-sm">{link.text}</Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
             <p className="text-lg font-semibold text-white mb-4">Servicios Destacados</p>
            <ul className="space-y-2">
              <li><span className="text-sm">Asesoramiento en Venta y Compra</span></li>
              <li><span className="text-sm">Publicación y Promoción</span></li>
              <li><span className="text-sm">Intermediación Segura</span></li>
              <li><span className="text-sm">Apoyo en Trámites Básicos</span></li>
            </ul>
          </div>
          
          <div>
            <p className="text-lg font-semibold text-white mb-4">Información de Contacto</p>
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                <span>Calle Falsa 123, Tarija, Bolivia</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-accent flex-shrink-0" />
                <a href="tel:+59170000000" className="hover:text-accent">+591 (7) 000-0000</a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-accent flex-shrink-0" />
                <a href="mailto:info@alvarezbienes.com" className="hover:text-accent">info@alvarezbienes.com</a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-700 mt-8 pt-8 text-center">
          <p className="text-sm text-slate-400">
            © {new Date().getFullYear()} AlvarezBienes Tarija. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;