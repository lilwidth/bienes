import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, MapPin, DollarSign, Tag } from 'lucide-react';

const SearchFilters = ({ onSearch, category, itemTypes }) => {
  const [filters, setFilters] = useState({
    keyword: '',
    itemType: '',
    minPrice: '',
    maxPrice: '',
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSearch = () => {
    onSearch(filters, category);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-card shadow-lg rounded-lg p-4 md:p-6 mb-8 border border-border"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
        <div className="lg:col-span-2">
          <label htmlFor="keyword" className="block text-sm font-medium text-muted-foreground mb-1">Palabra Clave / Ubicación</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="keyword"
              placeholder={category === 'Inmuebles' ? "Ej: Zona central, Lotes..." : "Ej: Toyota Hilux, Sofa..."}
              value={filters.keyword}
              onChange={(e) => handleFilterChange('keyword', e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        
        <div>
          <label htmlFor="itemType" className="block text-sm font-medium text-muted-foreground mb-1">Tipo de {category === 'Inmuebles' ? 'Inmueble' : category === 'Vehículos' ? 'Vehículo' : 'Bien'}</label>
          <Select onValueChange={(value) => handleFilterChange('itemType', value)} value={filters.itemType}>
            <SelectTrigger id="itemType">
              <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <SelectValue placeholder={`Todos los tipos`} className="pl-5"/>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos los tipos</SelectItem>
              {itemTypes.map(type => (
                <SelectItem key={type} value={type.toLowerCase()}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label htmlFor="minPrice" className="block text-sm font-medium text-muted-foreground mb-1">Precio Mín.</label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="minPrice"
              placeholder="Ej: 50000"
              type="number"
              value={filters.minPrice}
              onChange={(e) => handleFilterChange('minPrice', e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <label htmlFor="maxPrice" className="block text-sm font-medium text-muted-foreground mb-1">Precio Máx.</label>
           <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="maxPrice"
              placeholder="Ej: 200000"
              type="number"
              value={filters.maxPrice}
              onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>
      <div className="mt-4 flex justify-end">
        <Button 
          onClick={handleSearch}
          className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
        >
          <Search className="h-4 w-4 mr-2" />
          Buscar en {category}
        </Button>
      </div>
    </motion.div>
  );
};

export default SearchFilters;