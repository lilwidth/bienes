import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { Phone, Mail, MapPin, Send, MessageSquare } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', phone: '', message: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí iría la lógica para enviar el formulario (ej. a un backend o emailjs)
    console.log("Formulario enviado:", formData);
    toast({
      title: "Mensaje Enviado",
      description: "Gracias por contactarnos. Nos pondremos en contacto contigo pronto.",
      variant: "success",
    });
    setFormData({ name: '', phone: '', message: '' });
  };

  const contactInfo = [
    { icon: <Phone className="h-6 w-6 text-accent" />, text: "+591 (7) 000-0000", href: "tel:+59170000000", label: "Llámanos" },
    { icon: <MessageSquare className="h-6 w-6 text-accent" />, text: "Chatea por WhatsApp", href: "https://wa.me/59170000000", label: "WhatsApp" },
    { icon: <Mail className="h-6 w-6 text-accent" />, text: "info@alvarezbienes.com", href: "mailto:info@alvarezbienes.com", label: "Envíanos un Email" },
    { icon: <MapPin className="h-6 w-6 text-accent" />, text: "Calle Falsa 123, Tarija, Bolivia", label: "Nuestra Ubicación (referencial)" },
  ];

  return (
    <div className="min-h-screen pt-28 pb-12 bg-gradient-to-br from-slate-50 to-sky-100">
      <div className="container mx-auto px-4 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Contáctanos</h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            ¿Tienes preguntas o quieres saber más? Estamos aquí para ayudarte.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-card p-8 rounded-xl shadow-xl border border-border"
          >
            <h2 className="text-2xl font-semibold mb-6 text-foreground">Envíanos un Mensaje</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-muted-foreground mb-1">Nombre Completo</label>
                <Input type="text" name="name" id="name" placeholder="Tu nombre" value={formData.name} onChange={handleChange} required className="bg-secondary/50"/>
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-muted-foreground mb-1">Número de Teléfono</label>
                <Input type="tel" name="phone" id="phone" placeholder="Tu número de contacto" value={formData.phone} onChange={handleChange} required className="bg-secondary/50"/>
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-muted-foreground mb-1">Mensaje</label>
                <Textarea name="message" id="message" rows="4" placeholder="Escribe tu consulta aquí..." value={formData.message} onChange={handleChange} required className="bg-secondary/50"/>
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-lg py-3">
                <Send className="h-5 w-5 mr-2" />
                Enviar Mensaje
              </Button>
            </form>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-semibold mb-2 text-foreground">Otras Formas de Contacto</h2>
            {contactInfo.map((info, index) => (
              <div key={index} className="flex items-start space-x-4 p-4 bg-card rounded-lg shadow-md border border-border">
                <div className="flex-shrink-0 mt-1">{info.icon}</div>
                <div>
                  <p className="font-medium text-foreground">{info.label}</p>
                  {info.href ? (
                    <a href={info.href} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                      {info.text}
                    </a>
                  ) : (
                    <p className="text-muted-foreground">{info.text}</p>
                  )}
                </div>
              </div>
            ))}
             <div className="mt-6">
                <iframe 
                    src="https://www.openstreetmap.org/export/embed.html?bbox=-64.75682258605958%2C-21.53953153889026%2C-64.70893859863283%2C-21.518002029166807&layer=mapnik&marker=-21.52876707506044%2C-64.7328805923462" 
                    className="w-full h-64 rounded-lg shadow-md border border-border"
                    loading="lazy"
                    title="Mapa de Tarija"
                    aria-label="Mapa de Tarija mostrando ubicación referencial">
                </iframe>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;