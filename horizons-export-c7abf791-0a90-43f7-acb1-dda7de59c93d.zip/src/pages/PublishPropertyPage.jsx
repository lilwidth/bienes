import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { UploadCloud, Send, Tag, MapPin, DollarSign, FileText } from 'lucide-react';

const propertyTypes = ["Casa", "Departamento", "Terreno Urbano", "Terreno Rural", "Local Comercial", "Auto", "Moto", "Camioneta", "Camión", "Maquinaria", "Muebles", "Equipos o Herramientas"];

const PublishPropertyPage = () => {
  const [formData, setFormData] = useState({
    ownerName: '',
    propertyType: '',
    location: '',
    photos: [],
    suggestedPrice: '',
    description: ''
  });
  const [fileNames, setFileNames] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, propertyType: value }));
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setFormData(prev => ({ ...prev, photos: files }));
    setFileNames(files.map(file => file.name));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Formulario de publicación:", formData);
    toast({
      title: "Solicitud de Publicación Enviada",
      description: "Gracias por enviar tu bien. Lo revisaremos y nos pondremos en contacto contigo pronto.",
      variant: "success",
    });
    setFormData({ ownerName: '', propertyType: '', location: '', photos: [], suggestedPrice: '', description: '' });
    setFileNames([]);
    // Reset file input if possible (might need a ref)
    const fileInput = document.getElementById('photos');
    if (fileInput) fileInput.value = '';
  };

  return (
    <div className="min-h-screen pt-28 pb-12 bg-gradient-to-br from-green-50 to-teal-100">
      <div className="container mx-auto px-4 max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Publica tu Bien</h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            ¿Quieres vender o alquilar? Completa el formulario y nosotros nos encargamos del resto.
          </p>
        </motion.div>

        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-card p-8 rounded-xl shadow-xl border border-border space-y-6"
        >
          <div>
            <label htmlFor="ownerName" className="block text-sm font-medium text-muted-foreground mb-1">Nombre del Propietario</label>
            <Input type="text" name="ownerName" id="ownerName" placeholder="Tu nombre completo" value={formData.ownerName} onChange={handleChange} required className="bg-secondary/50"/>
          </div>

          <div>
            <label htmlFor="propertyType" className="block text-sm font-medium text-muted-foreground mb-1">Tipo de Bien</label>
            <Select onValueChange={handleSelectChange} value={formData.propertyType}>
              <SelectTrigger id="propertyType" className="bg-secondary/50">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Selecciona el tipo de bien" className="pl-5"/>
              </SelectTrigger>
              <SelectContent>
                {propertyTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label htmlFor="location" className="block text-sm font-medium text-muted-foreground mb-1">Ubicación</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input type="text" name="location" id="location" placeholder="Ej: Barrio Miraflores, Calle Sucre #123" value={formData.location} onChange={handleChange} required className="pl-10 bg-secondary/50"/>
            </div>
          </div>
          
          <div>
            <label htmlFor="photos" className="block text-sm font-medium text-muted-foreground mb-1">Fotos del Bien (máx. 5)</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-border border-dashed rounded-md bg-secondary/30 hover:border-primary transition-colors">
              <div className="space-y-1 text-center">
                <UploadCloud className="mx-auto h-12 w-12 text-muted-foreground" />
                <div className="flex text-sm text-muted-foreground">
                  <label
                    htmlFor="photos"
                    className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary"
                  >
                    <span>Sube tus archivos</span>
                    <input id="photos" name="photos" type="file" className="sr-only" multiple accept="image/*" onChange={handleFileChange} />
                  </label>
                  <p className="pl-1">o arrástralos aquí</p>
                </div>
                <p className="text-xs text-muted-foreground">PNG, JPG, GIF hasta 10MB cada uno</p>
              </div>
            </div>
            {fileNames.length > 0 && (
              <div className="mt-2 text-sm text-muted-foreground">
                <p className="font-medium">Archivos seleccionados:</p>
                <ul className="list-disc list-inside">
                  {fileNames.map((name, index) => <li key={index}>{name}</li>)}
                </ul>
              </div>
            )}
          </div>

          <div>
            <label htmlFor="suggestedPrice" className="block text-sm font-medium text-muted-foreground mb-1">Precio Sugerido (USD)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input type="number" name="suggestedPrice" id="suggestedPrice" placeholder="Ej: 75000" value={formData.suggestedPrice} onChange={handleChange} required className="pl-10 bg-secondary/50"/>
            </div>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-muted-foreground mb-1">Descripción Adicional</label>
            <div className="relative">
              <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Textarea name="description" id="description" rows="4" placeholder="Detalles importantes, características, estado del bien, etc." value={formData.description} onChange={handleChange} required className="pl-10 bg-secondary/50"/>
            </div>
          </div>

          <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-lg py-3">
            <Send className="h-5 w-5 mr-2" />
            Enviar para Revisión
          </Button>
        </motion.form>
      </div>
    </div>
  );
};

export default PublishPropertyPage;