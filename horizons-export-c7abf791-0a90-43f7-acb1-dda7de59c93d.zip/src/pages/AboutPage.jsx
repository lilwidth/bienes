import React from 'react';
import { motion } from 'framer-motion';
import { User, CheckCircle, Award, MessageSquare } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="min-h-screen pt-28 pb-12 bg-gradient-to-br from-slate-50 to-gray-100">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Sobre Mí</h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Conoce más sobre quién está detrás de AlvarezBienes y nuestra filosofía de trabajo.
          </p>
        </motion.div>

        <div className="bg-card p-8 md:p-12 rounded-xl shadow-xl border border-border">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="flex-shrink-0"
            >
              <img 
                className="w-40 h-40 md:w-48 md:h-48 rounded-full object-cover shadow-lg border-4 border-accent"
                alt="Foto de Alexandro Alvarez, fundador de la agencia"
               src="https://images.unsplash.com/photo-1620028901154-2a26028de912" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center md:text-left"
            >
              <h2 className="text-3xl font-semibold text-foreground mb-2">Alexandro Alvarez</h2>
              <p className="text-accent font-medium mb-4">Fundador de AlvarezBienes Tarija</p>
              <p className="text-muted-foreground leading-relaxed">
                "Soy Alexandro Alvarez, fundador de esta agencia independiente con el objetivo de conectar compradores y vendedores de manera segura y profesional en Tarija. Trabajo con honestidad, compromiso y resultados."
              </p>
              <p className="text-muted-foreground leading-relaxed mt-3">
                Mi pasión es ayudar a las personas a encontrar el bien perfecto o a realizar la mejor transacción posible, siempre con un trato cercano y transparente.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-10 pt-8 border-t border-border"
          >
            <h3 className="text-2xl font-semibold text-foreground mb-6 text-center">Nuestros Valores</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: <CheckCircle className="h-8 w-8 text-green-500" />, title: "Honestidad", description: "Transparencia total en cada gestión y comunicación." },
                { icon: <Award className="h-8 w-8 text-blue-500" />, title: "Compromiso", description: "Dedicación plena para alcanzar tus objetivos inmobiliarios." },
                { icon: <MessageSquare className="h-8 w-8 text-purple-500" />, title: "Resultados", description: "Enfoque en la eficiencia y satisfacción del cliente." }
              ].map((value, index) => (
                <div key={index} className="flex items-start space-x-3 p-4 bg-secondary/50 rounded-lg">
                  <div className="flex-shrink-0 mt-1">{value.icon}</div>
                  <div>
                    <h4 className="font-semibold text-foreground">{value.title}</h4>
                    <p className="text-sm text-muted-foreground">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
        
        <motion.section 
          id="testimonios" 
          className="py-16 mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Testimonios</h2>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              Lo que nuestros clientes dicen sobre nosotros (ejemplos).
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { name: "Maria Gonzales", testimony: "¡Excelente servicio! Alexandro me ayudó a vender mi casa rápidamente y al mejor precio. Muy profesional y atento.", image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=50&q=60" },
              { name: "Juan Perez", testimony: "Compré mi primer auto gracias a AlvarezBienes. El proceso fue muy sencillo y transparente. ¡Totalmente recomendado!", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=50&q=60" },
            ].map((testimonial, index) => (
              <motion.div 
                key={index} 
                className="bg-card p-6 rounded-lg shadow-lg border border-border"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 + index * 0.1, duration: 0.5 }}
              >
                <div className="flex items-center mb-4">
                  <img src={testimonial.image} alt={`Foto de ${testimonial.name}`} className="w-12 h-12 rounded-full mr-4 object-cover" />
                  <div>
                    <h4 className="font-semibold text-foreground">{testimonial.name}</h4>
                  </div>
                </div>
                <p className="text-muted-foreground italic">"{testimonial.testimony}"</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

      </div>
    </div>
  );
};

export default AboutPage;