import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, HeartHandshake as Handshake, Search, FileText, Award, Home } from 'lucide-react';

const services = [
  {
    icon: <Handshake className="h-12 w-12 text-accent" />,
    title: "Asesoramiento en Venta y Compra",
    description: "Te guiamos en cada paso del proceso de compra o venta, asegurando una transacción informada y beneficiosa para ti."
  },
  {
    icon: <Search className="h-12 w-12 text-accent" />,
    title: "Publicación y Promoción en Redes",
    description: "Maximizamos la visibilidad de tu bien utilizando estrategias de marketing digital y promoción efectiva en redes sociales."
  },
  {
    icon: <Briefcase className="h-12 w-12 text-accent" />,
    title: "Intermediación Segura",
    description: "Facilitamos la comunicación y negociación entre partes, garantizando un acuerdo justo y transparente."
  },
  {
    icon: <FileText className="h-12 w-12 text-accent" />,
    title: "Apoyo en Trámites Básicos",
    description: "Te asistimos con la documentación y los procedimientos necesarios para la transferencia, contratos y otros trámites esenciales."
  },
  {
    icon: <Award className="h-12 w-12 text-accent" />,
    title: "Tasaciones (Opcional)",
    description: "Ofrecemos servicios de tasación profesional para determinar el valor justo de mercado de tu propiedad o vehículo (consultar disponibilidad)."
  },
  {
    icon: <Home className="h-12 w-12 text-accent" />,
    title: "Alquiler de Propiedades",
    description: "Gestionamos el alquiler de tu propiedad, encontrando inquilinos confiables y administrando los contratos."
  }
];

const ServicesPage = () => {
  return (
    <div className="min-h-screen pt-28 pb-12 bg-gradient-to-br from-sky-50 to-indigo-100">
      <div className="container mx-auto px-4 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Nuestros Servicios</h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Comprometidos a brindarte soluciones integrales y profesionales en el sector de bienes raíces y vehículos.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-card p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 border border-border flex flex-col items-center text-center"
            >
              <div className="mb-4 p-3 bg-accent/10 rounded-full">
                {service.icon}
              </div>
              <h2 className="text-xl font-semibold mb-2 text-foreground">{service.title}</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;