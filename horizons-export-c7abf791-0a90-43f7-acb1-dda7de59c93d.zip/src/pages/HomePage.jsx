import React from 'react';
import Hero from '@/components/Hero';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Building, Car, Users, TrendingUp, CheckSquare } from 'lucide-react';
import PropertyCard from '@/components/PropertyCard';

const featuredProperties = [
  { id: 1, title: "Casa Moderna en Miraflores", type: "Casa", price: 180000, location: "Miraflores, Tarija", bedrooms: 3, bathrooms: 2, area: 150, imageDescription: "Casa moderna de dos plantas con jardín en Miraflores", category: 'Inmuebles' },
  { id: 2, title: "Toyota Hilux 2022", type: "Camioneta", price: 35000, location: "Tarija Centro", year: 2022, mileage: "25,000", imageDescription: "Camioneta Toyota Hilux 4x4 color rojo", category: 'Vehículos' },
  { id: 3, title: "Departamento Céntrico Amoblado", type: "Departamento", price: 95000, location: "Plaza Principal, Tarija", bedrooms: 2, bathrooms: 1, area: 80, imageDescription: "Departamento amoblado con balcon en el centro de Tarija", category: 'Inmuebles' },
];

const HomePage = () => {
  return (
    <>
      <Hero />
      <section id="destacados" className="py-16 bg-secondary">
        <div className="container mx-auto px-4 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Bienes Destacados</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Una selección de nuestras mejores propiedades y vehículos disponibles actualmente.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((item, index) => (
              <PropertyCard key={item.id} item={item} index={index} category={item.category} />
            ))}
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center mt-12"
          >
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Link to="/catalogo">Ver Todo el Catálogo</Link>
            </Button>
          </motion.div>
        </div>
      </section>

      <section id="por-que-elegirnos" className="py-16">
        <div className="container mx-auto px-4 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">¿Por Qué Elegirnos?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Ofrecemos un servicio personalizado y profesional para asegurar tu satisfacción.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: <Users className="h-10 w-10 text-accent mb-3" />, title: "Atención Personalizada", description: "Nos enfocamos en tus necesidades para encontrar la mejor solución." },
              { icon: <TrendingUp className="h-10 w-10 text-accent mb-3" />, title: "Resultados Comprobados", description: "Experiencia y dedicación para lograr tus objetivos." },
              { icon: <CheckSquare className="h-10 w-10 text-accent mb-3" />, title: "Proceso Transparente", description: "Te mantenemos informado en cada paso de la transacción." },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.15 }}
                className="bg-card p-6 rounded-lg shadow-lg text-center border border-border"
              >
                {feature.icon}
                <h3 className="text-xl font-semibold mb-2 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;