import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import SearchFilters from '@/components/SearchFilters';
import PropertyCard from '@/components/PropertyCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from '@/components/ui/use-toast';
import { Building, Car, Wrench as Tool } from 'lucide-react';

const allItemsData = {
  inmuebles: [
    { id: 1, title: "Casa Amplia en Senac", type: "Casa", price: 220000, location: "Senac, Tarija", bedrooms: 4, bathrooms: 3, area: 200, description: "Hermosa casa con patio grande, ideal para familias.", imageDescription: "Casa espaciosa de dos pisos con jardín frontal en Senac" },
    { id: 2, title: "Departamento Moderno Centro", type: "Departamento", price: 85000, location: "Centro, Tarija", bedrooms: 2, bathrooms: 1, area: 75, description: "Departamento luminoso con acabados de lujo.", imageDescription: "Interior de departamento moderno con vista a la ciudad de Tarija" },
    { id: 3, title: "Terreno Urbano Av. Principal", type: "Terreno Urbano", price: 150000, location: "Av. La Paz, Tarija", area: 500, description: "Excelente terreno sobre avenida, ideal para comercio.", imageDescription: "Terreno urbano vacío en una avenida principal de Tarija" },
    { id: 4, title: "Finca Productiva San Lorenzo", type: "Terreno Rural", price: 300000, location: "San Lorenzo, Tarija", area: 50000, description: "Finca con viñedos y árboles frutales, lista para producir.", imageDescription: "Extensa finca rural con viñedos bajo el sol en San Lorenzo" },
    { id: 5, title: "Local Comercial El Molino", type: "Local Comercial", price: 1200, rent: true, location: "Zona El Molino, Tarija", area: 60, description: "Local en esquina muy transitada, perfecto para tienda.", imageDescription: "Frente de un local comercial moderno en una esquina de El Molino" },
  ],
  vehiculos: [
    { id: 6, title: "Toyota Corolla 2021", type: "Auto", price: 23000, location: "Tarija", year: 2021, mileage: "30,000", description: "Auto sedan confiable y económico, perfecto estado.", imageDescription: "Auto Toyota Corolla sedan color blanco aparcado" },
    { id: 7, title: "Motocicleta Honda XR150", type: "Moto", price: 2800, location: "Tarija", year: 2023, mileage: "5,000", description: "Moto todo terreno ágil y potente, como nueva.", imageDescription: "Motocicleta Honda XR150 roja y blanca en terreno" },
    { id: 8, title: "Camioneta Nissan Frontier", type: "Camioneta", price: 32000, location: "Tarija", year: 2020, mileage: "45,000", description: "Camioneta 4x4 robusta, ideal para trabajo y aventura.", imageDescription: "Camioneta Nissan Frontier gris oscuro en un camino de tierra" },
    { id: 9, title: "Camión Volvo FH16", type: "Camión", price: 85000, location: "Tarija", year: 2018, mileage: "250,000", description: "Camión de carga pesada, excelente rendimiento y capacidad.", imageDescription: "Camión Volvo FH16 azul grande en carretera" },
  ],
  otros: [
    { id: 10, title: "Tractor Agrícola John Deere", type: "Maquinaria", price: 45000, location: "Valle de la Concepción", description: "Tractor en buen estado, listo para trabajar la tierra.", imageDescription: "Tractor agrícola John Deere verde en un campo cultivado" },
    { id: 11, title: "Juego de Comedor Madera Maciza", type: "Muebles", price: 800, location: "Tarija", description: "Elegante juego de comedor para 6 personas, alta calidad.", imageDescription: "Juego de comedor de madera maciza con seis sillas en una habitación" },
    { id: 12, title: "Herramientas de Carpintería", type: "Equipos", price: 300, location: "Tarija", description: "Set completo de herramientas manuales para carpintería.", imageDescription: "Varias herramientas de carpintería ordenadas sobre una mesa de trabajo" },
  ],
};

const categoryDetails = {
  inmuebles: { name: "Inmuebles", icon: <Building className="mr-2 h-5 w-5" />, types: ["Casa", "Departamento", "Terreno Urbano", "Terreno Rural", "Local Comercial"] },
  vehiculos: { name: "Vehículos", icon: <Car className="mr-2 h-5 w-5" />, types: ["Auto", "Moto", "Camioneta", "Camión"] },
  otros: { name: "Otros Bienes", icon: <Tool className="mr-2 h-5 w-5" />, types: ["Maquinaria", "Muebles", "Equipos o Herramientas"] },
};

const CatalogPage = () => {
  const [activeTab, setActiveTab] = useState("inmuebles");
  const [filteredItems, setFilteredItems] = useState(allItemsData.inmuebles);

  useEffect(() => {
    setFilteredItems(allItemsData[activeTab] || []);
  }, [activeTab]);

  const handleSearch = (filters, categoryKey) => {
    let itemsToFilter = allItemsData[categoryKey] || [];

    if (filters.keyword) {
      itemsToFilter = itemsToFilter.filter(item =>
        item.title.toLowerCase().includes(filters.keyword.toLowerCase()) ||
        (item.location && item.location.toLowerCase().includes(filters.keyword.toLowerCase())) ||
        (item.description && item.description.toLowerCase().includes(filters.keyword.toLowerCase()))
      );
    }
    if (filters.itemType) {
      itemsToFilter = itemsToFilter.filter(item => item.type.toLowerCase() === filters.itemType.toLowerCase());
    }
    if (filters.minPrice) {
      itemsToFilter = itemsToFilter.filter(item => item.price >= parseInt(filters.minPrice));
    }
    if (filters.maxPrice) {
      itemsToFilter = itemsToFilter.filter(item => item.price <= parseInt(filters.maxPrice));
    }

    setFilteredItems(itemsToFilter);
    toast({
      title: "Búsqueda Actualizada",
      description: `Se encontraron ${itemsToFilter.length} ${categoryDetails[categoryKey].name.toLowerCase()} que coinciden.`,
    });
  };

  return (
    <div className="min-h-screen pt-24 pb-12 bg-secondary">
      <div className="container mx-auto px-4 max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Catálogo de Bienes</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explora nuestra amplia selección de inmuebles, vehículos y otros bienes disponibles en Tarija.
          </p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 mb-6 h-auto">
            {Object.keys(categoryDetails).map(key => (
              <TabsTrigger key={key} value={key} className="py-3 text-base data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md">
                {categoryDetails[key].icon}
                {categoryDetails[key].name}
              </TabsTrigger>
            ))}
          </TabsList>

          {Object.keys(categoryDetails).map(categoryKey => (
            <TabsContent key={categoryKey} value={categoryKey}>
              <SearchFilters
                onSearch={handleSearch}
                category={categoryDetails[categoryKey].name}
                itemTypes={categoryDetails[categoryKey].types}
              />
              {filteredItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredItems.map((item, index) => (
                    <PropertyCard key={item.id} item={item} index={index} category={categoryDetails[categoryKey].name} />
                  ))}
                </div>
              ) : (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center text-muted-foreground py-10 text-lg"
                >
                  No se encontraron {categoryDetails[categoryKey].name.toLowerCase()} que coincidan con tu búsqueda.
                </motion.p>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
};

export default CatalogPage;